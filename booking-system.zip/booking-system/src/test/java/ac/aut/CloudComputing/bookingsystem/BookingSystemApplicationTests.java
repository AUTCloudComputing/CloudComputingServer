package ac.aut.CloudComputing.bookingsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
